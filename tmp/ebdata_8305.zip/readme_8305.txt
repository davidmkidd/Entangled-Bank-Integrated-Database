Entangled Bank Output 07/04/11 12:11:31
================================================================

 2 queries

 biotree_1  biotree_2 UNION

1 outputs

biotree_1: RETURN pruned(bioname) FROM Mammal Supertree (msw05) WITH 'Best date MYA' AS newick
files: 
 biotree_1_8305.tre


SQL
================================================================

biotree_2 Names SQL:
SELECT bioname FROM ( 
 SELECT * FROM biosql.lca_subtree_label_by_label(ARRAY['2279 Metatheria'], 14) AS bioname UNION  SELECT * FROM biosql.lca_subtree_label_by_label(ARRAY['2 Monotremata'], 14) AS bioname) AS foo

biotree_2Series SQL:
SELECT m."MainID" AS mid 
FROM gpdd.main m, gpdd.taxon t 
WHERE m."TaxonID" = t."TaxonID" 
AND t.binomial IN ( 
SELECT bioname FROM ( 
 SELECT * FROM biosql.lca_subtree_label_by_label(ARRAY['2279 Metatheria'], 14) AS bioname UNION  SELECT * FROM biosql.lca_subtree_label_by_label(ARRAY['2 Monotremata'], 14) AS bioname) AS foo)

 
----------------------------------------------------------------

biotree_1 Names SQL:
 SELECT * FROM biosql.lca_subtree_label_by_label(ARRAY['2279 Metatheria'], 14) AS bioname

biotree_1Series SQL:
SELECT m."MainID" AS mid 
FROM gpdd.main m, gpdd.taxon t 
WHERE m."TaxonID" = t."TaxonID" 
AND t.binomial IN ( 
 SELECT * FROM biosql.lca_subtree_label_by_label(ARRAY['2279 Metatheria'], 14) AS bioname)

 
----------------------------------------------------------------

