Entangled Bank Output 07/19/11 15:17:14
================================================================

 1 query 1 queries

 bionames_1

1 outputs

bovidae: RETURN pruned(bioname) FROM Mammal Supertree (msw05) WITH 'Best date MYA' AS newick
files: 
 bovidae_60e0.tre


SQL
================================================================

bionames_1 Names SQL:
SELECT label AS bioname 
			  FROM biosql.node WHERE node.tree_id = 14 AND label = ANY(ARRAY['Ovis ammon','Syncerus caffer','Alcelaphus buselaphus','Ammodorcas clarkei','Beatragus hunteri','Cephalophus spadix','Cephalophus weynsi','Cephalophus zebra','Taurotragus derbianus','Taurotragus oryx','Tetracerus quadricornis','Tragelaphus buxtoni','Tragelaphus eurycerus','Tragelaphus imberbis','Tragelaphus scriptus','Tragelaphus spekii','Tragelaphus strepsiceros','Bos frontalis','Bos javanicus','Boselaphus tragocamelus','Bison bison','Connochaetes gnou','Connochaetes taurinus','Capricornis crispus','Capricornis milneedwardsii','Cephalophus dorsalis','Cephalophus jentinki','Cephalophus leucogaster','Cephalophus niger','Gazella bennettii','Gazella cuvieri','Gazella dorcas','Bos grunniens','Bos sauveli','Bos taurus','Damaliscus pygargus','Damaliscus korrigum','Damaliscus lunatus','Dorcatragus megalotis','Capra ibex','Gazella erlangeri','Gazella gazella','Gazella leptoceros','Hemitragus hylocrius','Hemitragus jayakari','Hemitragus jemlahicus','Cephalophus natalensis','Litocranius walleri','Philantomba monticola','Raphicerus melanotis','Raphicerus sharpei','Alcelaphus lichtensteinii','Capra nubiana','Capra pyrenaica','Cephalophus brookei','Cephalophus callipygus','Gazella spekei','Tragelaphus angasii','Kobus vardonii','Nanger soemmerringii','Neotragus batesi','Neotragus moschatus','Neotragus pygmaeus','Oreotragus oreotragus','Ourebia ourebi','Ovibos moschatus','Ovis canadensis','Philantomba maxwellii','Hippotragus equinus','Hippotragus niger','Rupicapra rupicapra','Saiga borealis','Sylvicapra grimmia','Kobus ellipsiprymnus','Kobus kob','Kobus leche','Kobus megaceros','Addax nasomaculatus','Madoqua guentheri','Madoqua kirkii','Madoqua saltiana','Madoqua piacentinii','Aepyceros melampus','Cephalophus silvicultor','Alcelaphus caama','Nanger dama','Oreamnos americanus','Naemorhedus baileyi','Naemorhedus caudatus','Naemorhedus griseus','Capra sibirica','Capra walie','Capricornis rubidus','Capricornis sumatraensis','Capricornis swinhoei','Capricornis thar','Naemorhedus goral','Nanger granti','Oryx beisa','Oryx gazella','Antilope cervicapra','Ammotragus lervia','Ovis dalli','Oryx dammah','Pantholops hodgsonii','Antidorcas marsupialis','Pelea capreolus','Ovis nivicola','Bubalus mindorensis','Bubalus quarlesi','Budorcas taxicolor','Procapra picticaudata','Procapra przewalskii','Raphicerus campestris','Bubalus bubalis','Bubalus depressicornis','Redunca arundinum','Pseudois nayaur','Pseudois schaeferi','Rupicapra pyrenaica','Gazella subgutturosa','Eudorcas rufifrons','Eudorcas thomsonii','Cephalophus nigrifrons','Cephalophus ogilbyi','Cephalophus rufilatus','Procapra gutturosa','Redunca fulvorufula','Redunca redunca','Saiga tatarica','Capra caucasica','Capra falconeri','Cephalophus adersi'])

 
----------------------------------------------------------------

