Entangled Bank Output 06/29/11 13:29:25
================================================================

 4 queries

 Rodentia  Bodysize INTERSECT  north INTERSECT  biotemporal_1 INTERSECT

2 outputs

biotree_1: RETURN subtree(bioname) FROM Mammal Supertree (msw05) WITH 'Best date MYA' AS newick
files: 
 biotree_1_bc3c.tre
biogeographic_1: RETURN Mammal Ranges (msw05) AS shapefile
files: 
 /biogeographic_1_bc3c.shp
 /biogeographic_1_bc3c.shx
 /biogeographic_1_bc3c.dbf


SQL
================================================================

biotemporal_1 Names SQL:
SELECT bioname FROM ( 
SELECT bioname FROM ( 
SELECT bioname FROM ( 
 SELECT * FROM biosql.lca_subtree_tip_label_by_label(ARRAY['Rodentia'], 26) AS bioname INTERSECT SELECT d.msw05_binomial AS bioname  FROM msw05.msw05_pantheria d WHERE d."5-1_AdultBodyMass_g" >= 4.99 AND  d."5-1_AdultBodyMass_g" <= 45) AS foo INTERSECT SELECT bioname FROM (SELECT msw05_binomial AS bioname FROM msw05.msw05_geographic WHERE geog::geometry && 'srid=4326;POLYGON((-180 0, -180 90, 180 90, 180 0, -180 0))'::geometry) as bioname GROUP BY bioname HAVING COUNT(*) >= 1) AS foo INTERSECT SELECT bioname FROM (SELECT bioname 
				FROM ( 
					SELECT t.binomial AS bioname, 
					MIN(d."DecimalYearBegin") AS dstart, 
					MAX(d."DecimalYearEnd") AS dfinish
					FROM gpdd.taxon t,
					gpdd.main m,
					gpdd.data d
					WHERE m."MainID" = d."MainID"
					AND m."TaxonID" = t."TaxonID"
					AND t.binomial IS NOT NULL GROUP BY t.binomial
					HAVING MAX(d."DecimalYearBegin") >= 1500
					AND (MIN(d."DecimalYearEnd") >= 1900.08767123 AND MAX(d."DecimalYearBegin") <= 2001.08493151)
					) AS foo) as bioname GROUP BY bioname HAVING COUNT(*) >= 1) AS foo

biotemporal_1Series SQL:
SELECT m."MainID" AS mid 
FROM gpdd.main m, gpdd.taxon t 
WHERE m."TaxonID" = t."TaxonID" 
AND t.binomial IN ( 
SELECT bioname FROM ( 
SELECT bioname FROM ( 
SELECT bioname FROM ( 
 SELECT * FROM biosql.lca_subtree_tip_label_by_label(ARRAY['Rodentia'], 26) AS bioname INTERSECT SELECT d.msw05_binomial AS bioname  FROM msw05.msw05_pantheria d WHERE d."5-1_AdultBodyMass_g" >= 4.99 AND  d."5-1_AdultBodyMass_g" <= 45) AS foo INTERSECT SELECT bioname FROM (SELECT msw05_binomial AS bioname FROM msw05.msw05_geographic WHERE geog::geometry && 'srid=4326;POLYGON((-180 0, -180 90, 180 90, 180 0, -180 0))'::geometry) as bioname GROUP BY bioname HAVING COUNT(*) >= 1) AS foo INTERSECT SELECT bioname FROM (SELECT bioname 
				FROM ( 
					SELECT t.binomial AS bioname, 
					MIN(d."DecimalYearBegin") AS dstart, 
					MAX(d."DecimalYearEnd") AS dfinish
					FROM gpdd.taxon t,
					gpdd.main m,
					gpdd.data d
					WHERE m."MainID" = d."MainID"
					AND m."TaxonID" = t."TaxonID"
					AND t.binomial IS NOT NULL GROUP BY t.binomial
					HAVING MAX(d."DecimalYearBegin") >= 1500
					AND (MIN(d."DecimalYearEnd") >= 1900.08767123 AND MAX(d."DecimalYearBegin") <= 2001.08493151)
					) AS foo) as bioname GROUP BY bioname HAVING COUNT(*) >= 1) AS foo) AND m."MainID" IN (SELECT mid 
				FROM ( 
					SELECT m."MainID" AS mid, 
					MIN(d."DecimalYearBegin") AS dstart, 
					MAX(d."DecimalYearEnd") AS dfinish
					FROM gpdd.main m,
					gpdd.data d
					WHERE m."MainID" = d."MainID"
					GROUP BY m."MainID"
					HAVING MAX(d."DecimalYearBegin") >= 1500
					AND (MIN(d."DecimalYearEnd") >= 1900.08767123 AND MAX(d."DecimalYearBegin") <= 2001.08493151)
					) AS foo)

 
----------------------------------------------------------------

north Names SQL:
SELECT bioname FROM ( 
SELECT bioname FROM ( 
 SELECT * FROM biosql.lca_subtree_tip_label_by_label(ARRAY['Rodentia'], 26) AS bioname INTERSECT SELECT d.msw05_binomial AS bioname  FROM msw05.msw05_pantheria d WHERE d."5-1_AdultBodyMass_g" >= 4.99 AND  d."5-1_AdultBodyMass_g" <= 45) AS foo INTERSECT SELECT bioname FROM (SELECT msw05_binomial AS bioname FROM msw05.msw05_geographic WHERE geog::geometry && 'srid=4326;POLYGON((-180 0, -180 90, 180 90, 180 0, -180 0))'::geometry) as bioname GROUP BY bioname HAVING COUNT(*) >= 1) AS foo

northSeries SQL:
SELECT m."MainID" AS mid 
FROM gpdd.main m, gpdd.taxon t 
WHERE m."TaxonID" = t."TaxonID" 
AND t.binomial IN ( 
SELECT bioname FROM ( 
SELECT bioname FROM ( 
 SELECT * FROM biosql.lca_subtree_tip_label_by_label(ARRAY['Rodentia'], 26) AS bioname INTERSECT SELECT d.msw05_binomial AS bioname  FROM msw05.msw05_pantheria d WHERE d."5-1_AdultBodyMass_g" >= 4.99 AND  d."5-1_AdultBodyMass_g" <= 45) AS foo INTERSECT SELECT bioname FROM (SELECT msw05_binomial AS bioname FROM msw05.msw05_geographic WHERE geog::geometry && 'srid=4326;POLYGON((-180 0, -180 90, 180 90, 180 0, -180 0))'::geometry) as bioname GROUP BY bioname HAVING COUNT(*) >= 1) AS foo)

 
----------------------------------------------------------------

Bodysize Names SQL:
SELECT bioname FROM ( 
 SELECT * FROM biosql.lca_subtree_tip_label_by_label(ARRAY['Rodentia'], 26) AS bioname INTERSECT SELECT d.msw05_binomial AS bioname  FROM msw05.msw05_pantheria d WHERE d."5-1_AdultBodyMass_g" >= 4.99 AND  d."5-1_AdultBodyMass_g" <= 45) AS foo

BodysizeSeries SQL:
SELECT m."MainID" AS mid 
FROM gpdd.main m, gpdd.taxon t 
WHERE m."TaxonID" = t."TaxonID" 
AND t.binomial IN ( 
SELECT bioname FROM ( 
 SELECT * FROM biosql.lca_subtree_tip_label_by_label(ARRAY['Rodentia'], 26) AS bioname INTERSECT SELECT d.msw05_binomial AS bioname  FROM msw05.msw05_pantheria d WHERE d."5-1_AdultBodyMass_g" >= 4.99 AND  d."5-1_AdultBodyMass_g" <= 45) AS foo)

 
----------------------------------------------------------------

Rodentia Names SQL:
 SELECT * FROM biosql.lca_subtree_tip_label_by_label(ARRAY['Rodentia'], 26) AS bioname

RodentiaSeries SQL:
SELECT m."MainID" AS mid 
FROM gpdd.main m, gpdd.taxon t 
WHERE m."TaxonID" = t."TaxonID" 
AND t.binomial IN ( 
 SELECT * FROM biosql.lca_subtree_tip_label_by_label(ARRAY['Rodentia'], 26) AS bioname)

 
----------------------------------------------------------------

